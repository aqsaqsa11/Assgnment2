package com.example.myapplication23;

public class model {

    String mName;
    String mType;
    String mAddress;
    String mPrice;
    String mNew;
    String button;
    int img;

    public model(String mName , String mType ,  String mAddress, String mPrice,String mNew,String button,int img ) {
        this.mName=mName;
        this.mType=mType;
        this.mAddress=mAddress;
        this.mPrice=mPrice;
        this.mNew=mNew;
        this.button=button;
        this.img=img;
    }

    public String getName()
    {
        return mName;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public String getType() {
        return mType;
    }

    public void setType(String mType) {
        this.mType=mType;
    }
    public String getAddress() {
        return mAddress;
    }

    public void setAddress(String mAddress) {
        this.mAddress=mAddress;
    }
    public String getPrice() {
        return mPrice;
    }

    public void setPrice(String mPrice) {
        this.mPrice=mPrice;
    }
    public String getNew() {
        return mNew;
    }

    public void setNew(String mNew) {
        this.mNew=mNew;
    }

    public String getBtn() {
        return button;
    }

    public void setBtn(String button) {
        this.button=button;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img=img;
    }
}

