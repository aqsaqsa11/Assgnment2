package com.example.myapplication23;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import static com.example.myapplication23.R.drawable.ic_launcher_background;

public class MainActivity extends AppCompatActivity {
    Button btn;
    private List<model> list = new ArrayList<>();
    private RecyclerView recyclerView;
    private adapterlist mAdapter;

     


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = (Button)findViewById(R.id.btn1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,
                        MainActivity2.class);
                startActivity(intent);
            }
        });

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mAdapter = new adapterlist(list);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        preparedata();

    }
    private void preparedata() {
        model modelm = new model("Senior Software Engineer Data","HouseCanary","San Francisco,CA","$147K-$166K(Glassdoor Est)", "","EASY APPLY", R.drawable.download);
        list.add(modelm);
        modelm= new model("Staff Sofware Engineer","One Medical","San Francisco,CA","$177K-$170K(Glassdoor Est)", "NEW","EASY APPLY", R.drawable.icon);
        list.add(modelm);

        mAdapter.notifyDataSetChanged();
    }


}