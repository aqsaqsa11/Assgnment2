package com.example.myapplication23;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class adapterlist extends RecyclerView.Adapter<adapterlist.MyViewHolder>  {
    private List<model> list;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView mName;
        TextView mType;
        TextView mAddress;
        TextView mPrice;
        TextView mNew;
        Button button;
        ImageView img;

        public MyViewHolder(View view) {
            super(view);
            mName = (TextView) view.findViewById(R.id.textView1);
            mType = (TextView) view.findViewById(R.id.textView2);
            mAddress = (TextView) view.findViewById(R.id.textView3);
            mPrice = (TextView) view.findViewById(R.id.textView4);
            mNew = (TextView) view.findViewById(R.id.textView5);
            button = (Button) view.findViewById(R.id.button);
            img = (ImageView) view.findViewById(R.id.image1);
        }
    }
    public adapterlist(List<model> list) {
        this.list = list;
    }
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.listrow, parent, false);

        return new MyViewHolder(itemView);
    }
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        model mm = list.get(position);
        holder.mName.setText(mm.getName());

        holder.mType.setText(mm.getType());
        holder.mAddress.setText(mm.getAddress());
        holder.mPrice.setText(mm.getPrice());
        holder.mNew.setText(mm.getNew());
        holder.button.setText(mm.getBtn());
        holder.img.setImageAlpha(mm.getImg());
    }
    @Override
    public int getItemCount() {
        return list.size();
    }


    

}
